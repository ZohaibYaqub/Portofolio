import numpy as np

# Sigmoid Activation Function
def sigmoid(x):
    return 1 / (1 + np.exp(-x))

# Loss Function: Mean Squared Error (MSE)
def mse_loss(y_true, y_pred):
    return np.mean((y_true - y_pred) ** 2)

# Define dataset (6 samples, 3 features)
X = np.array([
    [0.8, 0.7, 0.3],  # High income, Good credit score, Low debt → Likely eligible
    [0.5, 0.9, 0.4],  # Medium income, Excellent credit score, Medium debt
    [0.2, 0.4, 0.8],  # Low income, Poor credit score, High debt → Not eligible
    [0.7, 0.6, 0.5],  # Good income, Average credit score, Medium debt
    [0.3, 0.5, 0.7],  # Low income, Average credit score, High debt
    [0.9, 0.8, 0.2]   # Very high income, Excellent credit score, Very low debt → Eligible
])

# Target labels (Binary classification: 1 = Eligible, 0 = Not Eligible)
y_true = np.array([[1], [1], [0], [1], [0], [1]])

# Initialize random weights and bias
np.random.seed(42)
W = np.random.randn(3, 1)  # 3 features → 1 output neuron
b = np.random.randn(1, 1)  # Single bias value

# Forward propagation (Z = XW + b)
Z = np.dot(X, W) + b
A = sigmoid(Z)  # Apply activation function

# Calculate loss
loss = mse_loss(y_true, A)

# Display results
print("\n🔹 **Single-Layer Perceptron Forward Propagation** 🔹\n")

print("🎲 **Randomly Generated Weights:**\n", W)
print("\n🎯 **Randomly Generated Bias:**\n", b)

print("\n📌 **Predicted Output (Before Thresholding):**\n", A)

# Convert predictions to binary class (Threshold = 0.5)
predicted_class = (A > 0.5).astype(int)
print("\n✅ **Final Predicted Class (Thresholded at 0.5):**\n", predicted_class)

print("\n📉 **Loss (Mean Squared Error - MSE):**", loss)
