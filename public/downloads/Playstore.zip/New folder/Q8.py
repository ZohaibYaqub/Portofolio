import numpy as np

# Sigmoid activation function
def sigmoid(x):
    return 1 / (1 + np.exp(-x))

# Define dataset (5 samples, 4 features)
X = np.array([
    [1, 0.5, 0.2, 0.8],
    [0.9, 0.7, 0.4, 0.6],
    [0.3, 0.8, 0.9, 0.1],
    [0.2, 0.1, 0.5, 0.7],
    [0.5, 0.4, 0.6, 0.3]
])

# Target labels (Binary classification)
y_true = np.array([[1], [1], [0], [0], [1]])

# Initialize random weights and biases
np.random.seed(42)
input_neurons = 4
hidden_neurons = 5
output_neurons = 1

W1 = np.random.randn(input_neurons, hidden_neurons)
b1 = np.random.randn(1, hidden_neurons)

W2 = np.random.randn(hidden_neurons, output_neurons)
b2 = np.random.randn(1, output_neurons)

# Forward propagation
Z1 = np.dot(X, W1) + b1
A1 = sigmoid(Z1)  # Activation at Hidden Layer

Z2 = np.dot(A1, W2) + b2
A2 = sigmoid(Z2)  # Final Predicted Output

# Print results
print("Multi-Layer Perceptron Approach\n")

print("Random Weights and Biases:")
print("\nW1 (Input to Hidden Layer):\n", W1)
print("\nb1 (Bias for Hidden Layer):\n", b1)
print("\nW2 (Hidden to Output Layer):\n", W2)
print("\nb2 (Bias for Output Layer):\n", b2)

print("\nOutputs at Each Layer:")
print("\nHidden Layer Output (A1):\n", A1)
print("\nFinal Predicted Output (A2 - Sigmoid Activation Applied):\n", A2)

# Predicted class (Threshold = 0.5)
predicted_class = (A2 > 0.5).astype(int)
print("\nPredicted Class:\n", predicted_class)
