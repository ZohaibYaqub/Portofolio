import numpy as np
import matplotlib.pyplot as plt
import networkx as nx

# Define the neural network parameters
inputs = [2.7, 3.3, 1.5, 4.2]  # 4 Inputs
weights = [0.4, 4.3, -1.2, 2.1]  # 4 Weights
bias = 0.2  # Bias

# Perform the dot product and calculate z
z = np.dot(weights, inputs) + bias

# Sigmoid activation function
def sigmoid(z):
    return 1 / (1 + np.exp(-z))

# Calculate output
output = sigmoid(z)

# Create the graph
G = nx.DiGraph()

# Add nodes for inputs, bias, dot product, sigmoid, and output
G.add_node("Input 1")
G.add_node("Input 2")
G.add_node("Input 3")
G.add_node("Input 4")
G.add_node("Bias 0.2")  # Bias inside the circle
G.add_node("Dot Product")  # Hidden Layer
G.add_node("Sigmoid")
G.add_node("Output")

# Add edges representing the flow of data
edges = [
    ("Input 1", "Dot Product"),
    ("Input 2", "Dot Product"),
    ("Input 3", "Dot Product"),
    ("Input 4", "Dot Product"),
    ("Bias 0.2", "Dot Product"),
    ("Dot Product", "Sigmoid"),
    ("Sigmoid", "Output")
]
G.add_edges_from(edges)

# Define edge labels (showing weights directly on input edges)
edge_labels = {
    ("Input 1", "Dot Product"): "w1 = 0.4",
    ("Input 2", "Dot Product"): "w2 = 4.3",
    ("Input 3", "Dot Product"): "w3 = -1.2",
    ("Input 4", "Dot Product"): "w4 = 2.1"
}

# Position the nodes in a layout
pos = {
    "Input 1": (0, 4),
    "Input 2": (0, 3),
    "Input 3": (0, 2),
    "Input 4": (0, 1),
    "Bias 0.2": (1, 2.5),
    "Dot Product": (2, 2.5),
    "Sigmoid": (3, 2.5),
    "Output": (4, 2.5)
}

# Draw the graph
plt.figure(figsize=(12, 7))
nx.draw(G, pos, with_labels=True, node_size=3000, node_color='lightgreen', font_size=10, font_weight='bold', arrows=True)
nx.draw_networkx_edge_labels(G, pos, edge_labels=edge_labels, font_size=10, font_color='red')

# Add computed values below the circles (nodes)
value_labels = {
    "Input 1": f"{inputs[0]}",
    "Input 2": f"{inputs[1]}",
    "Input 3": f"{inputs[2]}",
    "Input 4": f"{inputs[3]}",
    "Dot Product": f"z = {z:.4f}",
    "Sigmoid": f"σ(z) = {output:.4f}",
    "Output": f"{output:.4f}"
}

# Display computed values below each relevant node
for node, (x, y) in pos.items():
    if node in value_labels:
        plt.text(x, y - 0.3, value_labels[node], fontsize=10, ha='center', color='black')

# Set title and display
plt.title("Neural Network Forward Pass Flow with 4 Inputs")
plt.show()