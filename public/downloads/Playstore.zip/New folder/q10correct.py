import numpy as np

# Activation Function: Sigmoid
def sigmoid(x):
    return 1 / (1 + np.exp(-x))

# Loss Function: Mean Squared Error (MSE)
def mse_loss(y_true, y_pred):
    return np.mean((y_true - y_pred) ** 2)

# Define dataset (6 samples, 3 features)
X = np.array([
    [0.8, 0.7, 0.3],  # High income, Good credit score, Low debt → Likely eligible
    [0.5, 0.9, 0.4],  # Medium income, Excellent credit score, Medium debt
    [0.2, 0.4, 0.8],  # Low income, Poor credit score, High debt → Not eligible
    [0.7, 0.6, 0.5],  # Good income, Average credit score, Medium debt
    [0.3, 0.5, 0.7],  # Low income, Average credit score, High debt
    [0.9, 0.8, 0.2]   # Very high income, Excellent credit score, Very low debt → Eligible
])

# Target labels (Binary classification: 1 = Eligible, 0 = Not Eligible)
y_true = np.array([[1], [1], [0], [1], [0], [1]])

# Initialize random weights and biases
np.random.seed(42)

# Layer 1 (3 input neurons → 4 hidden neurons)
W1 = np.random.randn(3, 4)
b1 = np.random.randn(1, 4)

# Layer 2 (4 hidden neurons → 1 output neuron)
W2 = np.random.randn(4, 1)
b2 = np.random.randn(1, 1)

# Forward propagation: Layer 1 (Hidden Layer)
Z1 = np.dot(X, W1) + b1
A1 = sigmoid(Z1)

# Forward propagation: Layer 2 (Output Layer)
Z2 = np.dot(A1, W2) + b2
A2 = sigmoid(Z2)  # Final predicted values

# Compute Loss
loss = mse_loss(y_true, A2)

# Display results
print("\n🔹 **Multi-Layer Perceptron Forward Propagation** 🔹\n")

print("🎲 **Randomly Generated Weights (Layer 1):**\n", W1)
print("\n🎯 **Randomly Generated Bias (Layer 1):**\n", b1)

print("\n📌 **Output After Layer 1 (Hidden Layer Activation):**\n", A1)

print("\n🎲 **Randomly Generated Weights (Layer 2):**\n", W2)
print("\n🎯 **Randomly Generated Bias (Layer 2):**\n", b2)

print("\n📌 **Final Predicted Output (Before Thresholding):**\n", A2)

# Convert predictions to binary class (Threshold = 0.5)
predicted_class = (A2 > 0.5).astype(int)
print("\n✅ **Final Predicted Class (Thresholded at 0.5):**\n", predicted_class)

print("\n📉 **Loss (Mean Squared Error - MSE):**", loss)
