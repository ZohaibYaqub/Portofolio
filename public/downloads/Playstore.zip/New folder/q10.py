import numpy as np
import matplotlib.pyplot as plt
import networkx as nx

def sigmoid(x):
    return 1 / (1 + np.exp(-x))

def binary_cross_entropy(y_true, y_pred):
    return -np.mean(y_true * np.log(y_pred + 1e-9) + (1 - y_true) * np.log(1 - y_pred + 1e-9))

# Define dataset (6 samples, 3 features)
X = np.array([
    [1, 0.5, 0.2],
    [0.9, 0.7, 0.4],
    [0.3, 0.8, 0.9],
    [0.2, 0.1, 0.5],
    [0.5, 0.4, 0.6],
    [0.7, 0.3, 0.8]
])

# Target labels (Binary classification)
y_true = np.array([[1], [1], [0], [0], [1], [0]])

# Initialize random weights and bias
np.random.seed(42)
weights = np.random.randn(3, 1)  # 3 input features, 1 output neuron
bias = np.random.randn(1, 1)

print("Initial Random Weights:")
print(weights)
print("\nInitial Random Bias:")
print(bias)

# Forward propagation
z = np.dot(X, weights) + bias
y_pred = sigmoid(z)

print("\nPredicted Values:")
print(y_pred)

# Calculate Loss
loss = binary_cross_entropy(y_true, y_pred)
print("\nBinary Cross-Entropy Loss:", loss)

# Visualization of Single Layer Perceptron

def draw_perceptron_structure(weights, bias):
    G = nx.DiGraph()
    input_nodes = ["X1", "X2", "X3"]
    output_node = "Output"
    
    for i, inp in enumerate(input_nodes):
        G.add_edge(inp, output_node, weight=round(weights[i][0], 2))
    
    pos = {
        "X1": (-1, 1), "X2": (-1, 0), "X3": (-1, -1), "Output": (1, 0)
    }
    
    labels = {n: n for n in G.nodes()}
    edge_labels = {(u, v): d["weight"] for u, v, d in G.edges(data=True)}
    
    plt.figure(figsize=(6, 5))
    nx.draw(G, pos, with_labels=True, node_size=2000, node_color="lightblue", font_size=12, font_weight="bold")
    nx.draw_networkx_edge_labels(G, pos, edge_labels=edge_labels, font_size=10)
    plt.title("Single Layer Perceptron Structure")
    plt.show()

# Draw the perceptron structure
draw_perceptron_structure(weights, bias)
