import numpy as np
import matplotlib.pyplot as plt
import networkx as nx

# Define the neural network parameters
inputs = [float(input(f"Enter value for Input {i+1}: ")) for i in range(4)]  # Taking 4 inputs from the user

# Generate random weights for the hidden layer neurons
weights_hidden_1 = np.random.rand(4)  # 4 random weights for hidden layer 1
weights_hidden_2 = np.random.rand(4)  # 4 random weights for hidden layer 2

# Generate random biases for the hidden layer neurons
bias_hidden_1 = np.random.rand()  # Random bias for hidden layer 1
bias_hidden_2 = np.random.rand()  # Random bias for hidden layer 2

# Perform the dot product and calculate z for hidden layer neurons
z_hidden_1 = np.dot(weights_hidden_1, inputs) + bias_hidden_1
z_hidden_2 = np.dot(weights_hidden_2, inputs) + bias_hidden_2

# Sigmoid activation function
def sigmoid(z):
    return 1 / (1 + np.exp(-z))

# Calculate outputs for the hidden layer neurons
output_hidden_1 = sigmoid(z_hidden_1)
output_hidden_2 = sigmoid(z_hidden_2)

# Create the graph
G = nx.DiGraph()

# Add nodes for inputs, bias, hidden layer neurons, and output
G.add_node("Input 1")
G.add_node("Input 2")
G.add_node("Input 3")
G.add_node("Input 4")
G.add_node("Bias 1")  # Bias for hidden layer 1
G.add_node("Bias 2")  # Bias for hidden layer 2
G.add_node("(Neuron 1)")  # First hidden layer neuron
G.add_node("(Neuron 2)")  # Second hidden layer neuron
G.add_node("Sigmoid 1")
G.add_node("Sigmoid 2")
G.add_node("Output")

# Add edges representing the flow of data
edges = [
    ("Input 1", "(Neuron 1)"),
    ("Input 2", "(Neuron 1)"),
    ("Input 3", "(Neuron 1)"),
    ("Input 4", "(Neuron 1)"),
    ("Bias 1", "(Neuron 1)"),
    ("Input 1", "(Neuron 2)"),
    ("Input 2", "(Neuron 2)"),
    ("Input 3", "(Neuron 2)"),
    ("Input 4", "(Neuron 2)"),
    ("Bias 2", "(Neuron 2)"),
    ("(Neuron 1)", "Sigmoid 1"),
    ("(Neuron 2)", "Sigmoid 2"),
    ("Sigmoid 1", "Output"),
    ("Sigmoid 2", "Output")
]
G.add_edges_from(edges)

# Define edge labels (showing weights directly on input edges)
edge_labels = {
    ("Input 1", "(Neuron 1)"): f"w1 = {weights_hidden_1[0]:.2f}",
    ("Input 2", "(Neuron 1)"): f"w2 = {weights_hidden_1[1]:.2f}",
    ("Input 3", "(Neuron 1)"): f"w3 = {weights_hidden_1[2]:.2f}",
    ("Input 4", "(Neuron 1)"): f"w4 = {weights_hidden_1[3]:.2f}",
    ("Input 1", "(Neuron 2)"): f"w5 = {weights_hidden_2[0]:.2f}",
    ("Input 2", "(Neuron 2)"): f"w6 = {weights_hidden_2[1]:.2f}",
    ("Input 3", "(Neuron 2)"): f"w7 = {weights_hidden_2[2]:.2f}",
    ("Input 4", "(Neuron 2)"): f"w8 = {weights_hidden_2[3]:.2f}"
}

# Position the nodes in a layout
pos = {
    "Input 1": (0, 4),
    "Input 2": (0, 3),
    "Input 3": (0, 2),
    "Input 4": (0, 1),
    "Bias 1": (1, 3),
    "Bias 2": (1, 1),
    "(Neuron 1)": (2, 3),
    "(Neuron 2)": (2, 1),
    "Sigmoid 1": (3, 3),
    "Sigmoid 2": (3, 1),
    "Output": (4, 2)
}

# Draw the graph
plt.figure(figsize=(12, 7))
nx.draw(G, pos, with_labels=True, node_size=3000, node_color='lightgreen', font_size=10, font_weight='bold', arrows=True)
nx.draw_networkx_edge_labels(G, pos, edge_labels=edge_labels, font_size=10, font_color='red')

# Add computed values below the circles (nodes)
value_labels = {
    "Input 1": f"{inputs[0]}",
    "Input 2": f"{inputs[1]}",
    "Input 3": f"{inputs[2]}",
    "Input 4": f"{inputs[3]}",
    "Bias 1": f"Bias 1 = {bias_hidden_1:.2f}",
    "Bias 2": f"Bias 2 = {bias_hidden_2:.2f}",
    "(Neuron 1)": f"z1 = {z_hidden_1:.4f}",
    "(Neuron 2)": f"z2 = {z_hidden_2:.4f}",
    "Sigmoid 1": f"σ(z1) = {output_hidden_1:.4f}",
    "Sigmoid 2": f"σ(z2) = {output_hidden_2:.4f}",
    "Output": f"Output = {output_hidden_1 + output_hidden_2:.4f}"
}

# Display computed values below each relevant node
for node, (x, y) in pos.items():
    if node in value_labels:
        plt.text(x, y - 0.3, value_labels[node], fontsize=10, ha='center', color='black')

# Set title and display
plt.title("Neural Network Forward Pass Flow with 4 Inputs and 2 Hidden Neurons (Random Weights)")
plt.show()

# Print out the results
print(f"Inputs: {inputs}")
print(f"Random Weights (Hidden Layer 1): {weights_hidden_1}")
print(f"Random Weights (Hidden Layer 2): {weights_hidden_2}")
print(f"Biases: Bias 1 = {bias_hidden_1:.2f}, Bias 2 = {bias_hidden_2:.2f}")
print(f"Weighted Sums (z1, z2): z1 = {z_hidden_1:.4f}, z2 = {z_hidden_2:.4f}")
print(f"Activated Outputs (Sigmoid): Sigmoid 1 = {output_hidden_1:.4f}, Sigmoid 2 = {output_hidden_2:.4f}")
print(f"Final Output: {output_hidden_1 + output_hidden_2:.4f}")
