import numpy as np

# === Custom Activation Function (ReLU) ===
def relu(x):
    return np.maximum(0, x)

# === Layer Class ===
class Layer:
    def __init__(self, num_inputs, num_neurons):
        """Initialize layer with random weights and biases."""
        self.weights = np.random.randn(num_neurons, num_inputs)
        self.biases = np.random.randn(num_neurons)
    
    def forward(self, inputs):
        """Performs forward propagation."""
        self.z = np.dot(self.weights, inputs) + self.biases
        self.output = relu(self.z)
        return self.output

# === Step 1: Get User Inputs ===
num_inputs = int(input("Enter the number of input features: "))
inputs = np.array(list(map(float, input(f"Enter {num_inputs} input values: ").split())))

num_neurons_layer1 = int(input("Enter the number of neurons in Layer 1: "))
num_neurons_layer2 = int(input("Enter the number of neurons in Layer 2: "))
num_output_neurons = 1  # Output layer has a single neuron

# === Step 2: Create Layers ===
layer1 = Layer(num_inputs, num_neurons_layer1)
layer2 = Layer(num_neurons_layer1, num_neurons_layer2)
output_layer = Layer(num_neurons_layer2, num_output_neurons)

# === Step 3: Forward Propagation ===
hidden_layer1_output = layer1.forward(inputs)
hidden_layer2_output = layer2.forward(hidden_layer1_output)
final_output = output_layer.forward(hidden_layer2_output)

# === Display Results ===
print("\n=== Forward Propagation Results ===")
print(f"Inputs: {inputs}")

print("\nLayer 1")
print(f"   Weights:\n{layer1.weights}")
print(f"   Biases: {layer1.biases}")
print(f"   Z values: {layer1.z}")
print(f"   Activated Output: {hidden_layer1_output}")

print("\nLayer 2")
print(f"   Weights:\n{layer2.weights}")
print(f"   Biases: {layer2.biases}")
print(f"   Z values: {layer2.z}")
print(f"   Activated Output: {hidden_layer2_output}")

print("\nOutput Layer")
print(f"   Weights:\n{output_layer.weights}")
print(f"   Biases: {output_layer.biases}")
print(f"   Z value: {output_layer.z}")
print(f"   Final Output: {final_output}")
