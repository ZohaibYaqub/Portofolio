import random
import numpy as np


def sigmoid(x):
    return 1 / (1 + np.exp(-x))


inputs = [random.uniform(-1, 1) for _ in range(3)]
weights = [random.uniform(-1, 1) for _ in range(3)]
bias = random.uniform(-0.5, 0.5)


z = np.dot(weights, inputs) + bias
output = sigmoid(z)

print("\nRandomized Perceptron:")
print(f"Random Inputs: {inputs}")
print(f"Random Weights: {weights}")
print(f"Random Bias: {bias}")
print(f"Weighted Sum (z): {z}")
print(f"Activated Output: {output}")
