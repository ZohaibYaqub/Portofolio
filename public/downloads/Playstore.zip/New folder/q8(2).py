import numpy as np

# Sigmoid activation function
def sigmoid(x):
    return 1 / (1 + np.exp(-x))

# Define dataset (5 samples, 3 features)
X = np.array([
    [1, 0.5, 0.2],
    [0.9, 0.7, 0.4],
    [0.3, 0.8, 0.9],
    [0.2, 0.1, 0.5],
    [0.5, 0.4, 0.6]
])

# Target labels
y_true = np.array([[1], [1], [0], [0], [1]])

# Number of perceptrons
num_perceptrons = 3

# Initialize weights and biases for multiple perceptrons
np.random.seed(42)
W_perceptrons = [np.random.randn(X.shape[1], 1) for _ in range(num_perceptrons)]
b_perceptrons = [np.random.randn(1, 1) for _ in range(num_perceptrons)]

# Forward propagation for each perceptron
outputs = []
for i in range(num_perceptrons):
    Z = np.dot(X, W_perceptrons[i]) + b_perceptrons[i]
    A = sigmoid(Z)
    outputs.append(A)

# Combine outputs (averaging for final prediction)
final_output = np.mean(outputs, axis=0)

# Print results
print("Multi-Perceptron Approach\n")

for i in range(num_perceptrons):
    print(f"\nPerceptron {i+1} Weights:\n", W_perceptrons[i])
    print(f"\nPerceptron {i+1} Bias:\n", b_perceptrons[i])
    print(f"\nPerceptron {i+1} Output:\n", outputs[i])

print("\nFinal Combined Output (Averaged Perceptron Outputs):\n", final_output)

# Predicted class (Threshold = 0.5)
predicted_class = (final_output > 0.5).astype(int)
print("\nPredicted Class:\n", predicted_class)
