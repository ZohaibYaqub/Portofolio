import numpy as np


def sigmoid(x):
    return 1 / (1 + np.exp(-x))


def multi_layer_perceptron(inputs, weights1, weights2, bias1, bias2):
    # Layer 1
    z1 = np.dot(weights1, inputs) + bias1  # Weighted sum
    activated1 = sigmoid(z1)  # Activation

    # Layer 2
    z2 = np.dot(weights2, activated1) + bias2  # Weighted sum for Layer 2
    activated2 = sigmoid(z2)  # Final output activation

    return activated2


inputs = [1.0, 0.5]
weights1 = [[0.3, -0.2], [-0.1, 0.4]]  
weights2 = [0.5, -0.3]  
bias1 = [0.1, -0.2]  
bias2 = 0.3 

output = multi_layer_perceptron(inputs, weights1, weights2, bias1, bias2)
print("\nMulti-Layer Perceptron Output:")
print(f"Final Activated Output: {output}")
