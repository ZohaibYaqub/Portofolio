import numpy as np
import matplotlib.pyplot as plt
import networkx as nx

# Define user inputs
inputs = np.array([0.4, 0.5, 0.3, 0.2])  # Fixed input values
weights_hidden_1 = np.array([0.4, 0.5, -0.6, 0.1])
weights_hidden_2 = np.array([0.9, 0.1, -0.2, 0.4])
bias_hidden_1 = 0.2
bias_hidden_2 = 0.5

# Define activation function
def sigmoid(z):
    return 1 / (1 + np.exp(-z))

# Compute dot products
z_hidden_1 = np.dot(weights_hidden_1, inputs) + bias_hidden_1
z_hidden_2 = np.dot(weights_hidden_2, inputs) + bias_hidden_2

# Compute activations
output_hidden_1 = sigmoid(z_hidden_1)
output_hidden_2 = sigmoid(z_hidden_2)
final_output = output_hidden_1 + output_hidden_2

# Print computed values
print(f"Inputs: {inputs}")
print(f"Weights (Neuron 1): {weights_hidden_1}, Bias: {bias_hidden_1}")
print(f"Weights (Neuron 2): {weights_hidden_2}, Bias: {bias_hidden_2}")
print(f"z1: {z_hidden_1:.4f}, Activated Output 1: {output_hidden_1:.4f}")
print(f"z2: {z_hidden_2:.4f}, Activated Output 2: {output_hidden_2:.4f}")
print(f"Final Output: {final_output:.4f}")

# Create Graph
G = nx.DiGraph()

# Define nodes
nodes = [
    "Input 1", "Input 2", "Input 3", "Input 4", "Bias 1", "Bias 2",
    "Neuron 1", "Neuron 2", "Sigmoid 1", "Sigmoid 2", "Output"
]
G.add_nodes_from(nodes)

# Define edges
edges = [(f"Input {i+1}", "Neuron 1") for i in range(4)] + [("Bias 1", "Neuron 1")]
edges += [(f"Input {i+1}", "Neuron 2") for i in range(4)] + [("Bias 2", "Neuron 2")]
edges += [("Neuron 1", "Sigmoid 1"), ("Neuron 2", "Sigmoid 2"), ("Sigmoid 1", "Output"), ("Sigmoid 2", "Output")]
G.add_edges_from(edges)

# Define edge labels (showing weights)
edge_labels = {
    (f"Input {i+1}", "Neuron 1"): f"w{i+1} = {weights_hidden_1[i]:.2f}" for i in range(4)
}
edge_labels.update({
    (f"Input {i+1}", "Neuron 2"): f"w{i+5} = {weights_hidden_2[i]:.2f}" for i in range(4)
})

# Position nodes
pos = {
    "Input 1": (0, 4), "Input 2": (0, 3), "Input 3": (0, 2), "Input 4": (0, 1),
    "Bias 1": (1, 3), "Bias 2": (1, 1),
    "Neuron 1": (2, 3), "Neuron 2": (2, 1),
    "Sigmoid 1": (3, 3), "Sigmoid 2": (3, 1),
    "Output": (4, 2)
}

# Draw the graph
plt.figure(figsize=(12, 7))
nx.draw(G, pos, with_labels=True, node_size=3000, node_color='lightblue', font_size=10, font_weight='bold', arrows=True)
nx.draw_networkx_edge_labels(G, pos, edge_labels=edge_labels, font_size=9, font_color='red')

# Add computed values to nodes
value_labels = {
    "Input 1": f"{inputs[0]}", "Input 2": f"{inputs[1]}",
    "Input 3": f"{inputs[2]}", "Input 4": f"{inputs[3]}",
    "Bias 1": f"Bias = {bias_hidden_1}", "Bias 2": f"Bias = {bias_hidden_2}",
    "Neuron 1": f"z1 = {z_hidden_1:.2f}", "Neuron 2": f"z2 = {z_hidden_2:.2f}",
    "Sigmoid 1": f"σ(z1) = {output_hidden_1:.2f}", "Sigmoid 2": f"σ(z2) = {output_hidden_2:.2f}",
    "Output": f"Output = {final_output:.2f}"
}

# Display computed values below each node
for node, (x, y) in pos.items():
    if node in value_labels:
        plt.text(x, y - 0.3, value_labels[node], fontsize=10, ha='center', color='black')

# Display final output
plt.title("Neural Network Forward Pass with Weights, Inputs, and Biases")
plt.show()