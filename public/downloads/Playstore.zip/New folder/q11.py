import numpy as np

# Activation Function: Sigmoid
def sigmoid(x):
    return 1 / (1 + np.exp(-x))

# Derivative of Sigmoid
def sigmoid_derivative(x):
    return x * (1 - x)

# Loss Function: Mean Squared Error (MSE)
def mse_loss(y_true, y_pred):
    return np.mean((y_true - y_pred) ** 2)

# Learning Rate
lr = 0.1

# Define dataset (6 samples, 3 features)
X = np.array([
    [0.8, 0.7, 0.3],
    [0.5, 0.9, 0.4],
    [0.2, 0.4, 0.8],
    [0.7, 0.6, 0.5],
    [0.3, 0.5, 0.7],
    [0.9, 0.8, 0.2]
])

# Target labels (Binary classification)
y_true = np.array([[1], [1], [0], [1], [0], [1]])

# Initialize random weights and biases
np.random.seed(42)
W = np.random.randn(3, 1)  # Single-layer perceptron (3 input neurons → 1 output neuron)
b = np.random.randn(1, 1)

print("\n🔹 **Initial Weights and Bias:**")
print("🎲 Weights:\n", W)
print("🎯 Bias:\n", b)

# Training for 10 epochs (With Early Stopping)
for epoch in range(10):
    # Forward Propagation
    Z = np.dot(X, W) + b
    A = sigmoid(Z)

    # Compute Loss
    loss = mse_loss(y_true, A)

    # Display results
    print(f"\n📌 Epoch {epoch+1} | Loss: {loss:.6f}")

    print("\n🔹 Predicted Output Before Weight Update:\n", A)

    # Backward Propagation
    dA = 2 * (A - y_true) / y_true.size  # Derivative of loss (MSE)
    dZ = dA * sigmoid_derivative(A)  # Gradient w.r.t. Z
    dW = np.dot(X.T, dZ)  # Gradient w.r.t. Weights
    dB = np.sum(dZ, axis=0, keepdims=True)  # Gradient w.r.t. Bias

    # Update Weights & Bias
    W -= lr * dW
    b -= lr * dB

    print("\n🎯 Updated Weights:\n", W)
    print("🎯 Updated Bias:\n", b)

    # Check for early stopping (if loss is very low)
    if loss < 0.001:
        print("\n✅ Early stopping: Loss is minimized")
        break

# Final Prediction After Training
Z_final = np.dot(X, W) + b
A_final = sigmoid(Z_final)

print("\n📌 **Final Predictions After Training:**\n", A_final)
print("\n📉 **Final Loss:**", mse_loss(y_true, A_final))
